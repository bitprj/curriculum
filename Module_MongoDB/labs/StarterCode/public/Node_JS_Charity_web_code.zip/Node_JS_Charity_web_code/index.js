var element = document.getElementsByClassName("event-content")
console.log(element);